﻿// See https://aka.ms/new-console-template for more information
string nombre="Susana Yuvinca";
string apellido="Fernandez";
long dni = 95746418;
int edad=27;
double altura = 1.50;
Console.WriteLine("Nombre: " + nombre);
Console.WriteLine("Apellido: " + apellido);
Console.WriteLine("Dni: " + dni);
Console.WriteLine("Edad: " + edad + " años");
Console.WriteLine("Altura: " + altura);
